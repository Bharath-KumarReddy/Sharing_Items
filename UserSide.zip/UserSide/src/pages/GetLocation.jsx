import React from 'react'

const GetLocation = () => {
  return (
    <div>
      
    </div>
  )
}

export default GetLocation
